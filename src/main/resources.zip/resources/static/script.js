let selectedFlight = null;
let allFlights = [];

function showSection(sectionName) {
    document.querySelectorAll('section').forEach(section => {
        section.classList.remove('active');
    });

    document.getElementById(sectionName + '-section').classList.add('active');

    document.querySelectorAll('.nav-link').forEach(link => {
        link.classList.remove('active');
    });
    document.querySelector(`[data-section="${sectionName}"]`).classList.add('active');
}

document.querySelectorAll('.nav-link').forEach(link => {
    link.addEventListener('click', (e) => {
        e.preventDefault();
        const section = e.target.getAttribute('data-section');
        showSection(section);
    });
});

async function loadFlights() {
    const flightsSelect = document.getElementById("flights-select");
    const searchBtn = document.querySelector('.search-btn');

    try {
        searchBtn.textContent = 'Cargando...';
        searchBtn.disabled = true;
        flightsSelect.innerHTML = '<option value="">Cargando vuelos...</option>';

        console.log("Buscando vuelos...");

        let response;
        let attempts = 0;
        const maxAttempts = 3;

        while (attempts < maxAttempts) {
            try {
                response = await fetch("http://localhost:9000/vuelos", {
                    method: 'GET',
                    headers: { 'Content-Type': 'application/json' },
                    timeout: 5000
                });
                break;
            } catch (fetchError) {
                attempts++;
                console.log(`Intento ${attempts} fallido:`, fetchError.message);
                if (attempts < maxAttempts) await new Promise(resolve => setTimeout(resolve, 1000));
                else throw fetchError;
            }
        }

        if (!response.ok) throw new Error(`Error del servidor: ${response.status} - ${response.statusText}`);

        const vuelos = await response.json();
        allFlights = vuelos;

        flightsSelect.innerHTML = '<option value="">Selecciona un vuelo...</option>';

        if (!vuelos || vuelos.length === 0) {
            flightsSelect.innerHTML = '<option value="">No hay vuelos disponibles</option>';
            return;
        }

        vuelos.forEach((vuelo, index) => {
            const option = document.createElement('option');
            option.value = index;
            option.textContent = `#${vuelo.numeroVuelo || vuelo.id} | ${vuelo.origen || 'N/A'} ✈️ ${vuelo.destino || 'N/A'} | ${vuelo.fecha}`;
            flightsSelect.appendChild(option);
        });

    } catch (error) {
        console.error("Error al cargar vuelos:", error);
        let errorMessage = 'Error al cargar vuelos';
        if (error.message.includes('Failed to fetch')) {
            errorMessage = 'No se puede conectar al servidor. ¿Está ejecutándose en localhost:9000?';
        }
        flightsSelect.innerHTML = `<option value="">⚠️ ${errorMessage}</option>`;
    } finally {
        searchBtn.textContent = 'Explorar Vuelos';
        searchBtn.disabled = false;
    }
}

async function loadCardTypes() {
    try {
        const response = await fetch("http://localhost:9000/tarjetas");
        const tipos = await response.json();

        const select = document.getElementById("card-type");
        select.innerHTML = '<option value="">Selecciona un tipo</option>';
        tipos.forEach(tipo => {
            const option = document.createElement("option");
            option.value = tipo;
            option.textContent = tipo;
            select.appendChild(option);
        });
    } catch (error) {
        console.error("Error al cargar tipos de tarjeta", error);
        document.getElementById("card-type").innerHTML = '<option value="">Error al cargar</option>';
    }
}

document.addEventListener("DOMContentLoaded", () => {
    const form = document.getElementById("search-form");
    const flightsSelect = document.getElementById("flights-select");
    const flightInfo = document.getElementById("flight-info");
    const flightDetails = document.getElementById("flight-details");
    const reserveBtn = document.getElementById("reserve-btn");

    loadFlights();
    loadCardTypes();

    form.addEventListener("submit", async (e) => {
        e.preventDefault();
        await loadFlights();
    });

    flightsSelect.addEventListener('change', (e) => {
        const selectedIndex = e.target.value;

        if (selectedIndex === "") {
            flightInfo.style.display = 'none';
            reserveBtn.style.display = 'none';
            selectedFlight = null;
        } else {
            selectedFlight = allFlights[selectedIndex];

            flightDetails.innerHTML = `
               <strong>🛫 Origen:</strong> ${selectedFlight.origen || 'N/A'}<br>
               <strong>🛬 Destino:</strong> ${selectedFlight.destino || 'N/A'}<br>
               <strong>📅 Fecha:</strong> ${selectedFlight.fecha || 'N/A'}<br>
               <strong>💺 Número de Vuelo:</strong> ${selectedFlight.numeroVuelo || selectedFlight.id}<br>
               <strong>💲 Precio:</strong> $${selectedFlight.precio || 'Consultar'}
                `;


            flightInfo.style.display = 'block';
            reserveBtn.style.display = 'block';
        }
    });

    reserveBtn.addEventListener('click', () => {
        if (selectedFlight) {
            const bookingFlightDetails = document.getElementById('booking-flight-details');
            bookingFlightDetails.innerHTML = `
                <strong>🛫 Origen:</strong> ${selectedFlight.origen || 'N/A'}<br>
                <strong>🛬 Destino:</strong> ${selectedFlight.destino || 'N/A'}<br>
                <strong>📅 Fecha:</strong> ${selectedFlight.fecha || 'N/A'}<br>
                <strong>💺 Número de Vuelo:</strong> ${selectedFlight.numeroVuelo || selectedFlight.id}<br>
                <strong>💲 Precio:</strong> $${selectedFlight.precio || 'Consultar'}
            `;


            document.getElementById("total-price").value = selectedFlight.precio;

            showSection('booking');
        }
    });

    const bookingForm = document.getElementById('booking-form');
    bookingForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const numeroReserva = 'RES-' + Date.now().toString().slice(-6);

        const formData = {
            flight: selectedFlight,
            passenger: {
                dni: document.getElementById('passenger-dni').value,
                name: document.getElementById('passenger-name').value,
                lastname: document.getElementById('passenger-lastname').value,
                password: '1234',
                email: document.getElementById('passenger-email').value,
                reservas: [
                    {
                        numeroReserva: numeroReserva,
                        vueloId: selectedFlight.id,
                        origen: selectedFlight.origen,
                        destino: selectedFlight.destino,
                        fecha: selectedFlight.fecha,
                        precio: selectedFlight.precio,
                        tarjeta: {
                            numero: document.getElementById('card-number').value,
                            tipo: document.getElementById('card-type').value
                        }
                    }
                ]
            }
        };

        try {
            const response = await fetch('http://localhost:9000/usuarios', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(formData)
            });

            if (response.ok) {
                const result = await response.json();
                alert(`¡Reserva confirmada! Número de reserva: ${numeroReserva}`);
                bookingForm.reset();
                showSection('reservations');
            } else {
                throw new Error('Error al procesar la reserva');
            }
        } catch (error) {
            console.error('Error al enviar reserva:', error);
            alert('Error al procesar la reserva. Por favor, inténtalo nuevamente.');
        }
    });
});

function loadReservations() {
    const userId = document.getElementById('usuario-id').value;
    const reservationsList = document.getElementById('reservations-list');

    if (!userId) {
        reservationsList.innerHTML = '<p style="color: red;">Por favor ingresa un ID de usuario.</p>';
        return;
    }

    reservationsList.innerHTML = '<p>Cargando reservas...</p>';

    setTimeout(() => {
        reservationsList.innerHTML = '<p>No se encontraron reservas para este usuario.</p>';
    }, 1000);
}
